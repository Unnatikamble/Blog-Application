import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { UserProfileComponent } from 'src/app/Users/user-profile/user-profile.component';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  ngOnInit(): void {
    
  }

   @ViewChild('profileComponent') profileComponent!: UserProfileComponent;


  constructor(public authService: AuthServiceService) {}

  logout() {
    this.authService.logout();
  }

  openProfile() {
    this.profileComponent.openProfile();
  }

  

}
