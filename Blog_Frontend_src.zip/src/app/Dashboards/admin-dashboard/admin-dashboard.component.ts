import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { UserProfileComponent } from 'src/app/Users/user-profile/user-profile.component';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  ngOnInit(): void {
   
  }

  @ViewChild('profileComponent') profileComponent!: UserProfileComponent;


   constructor(public authService: AuthServiceService) {}

  Adminlogout() {
    this.authService.logout();
  }

  openProfile() {
    this.profileComponent.openProfile();
  }


}
