import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JwtAuthResponse } from 'src/app/Entities/jwt-auth-response';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { UserServiceService } from 'src/app/Services/user-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  loginForm: FormGroup;
  errorMessage: string='';


  constructor(private fb: FormBuilder,
     private authService: UserServiceService, private router: Router,private authService1: AuthServiceService) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  navigateToLogin() {
    this.router.navigate(['/register']);
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { username, password } = this.loginForm.value;
      this.authService.login(username, password).subscribe(
        (response: JwtAuthResponse) => {
          console.log('Login successful:', response);
          const userId = response.id;
          const token = response.token;
          
          const id=String(response.id);
          this.authService1.login(token,id);
          Swal.fire({
            title: "LOGIN",
            text: "Login-Successful!",
            icon: "success"
          }).then((result) => {
            if (result.isConfirmed) {
              // Navigate only if the user clicks "OK"
              this.router.navigate(['/user-registration/AllUsersPosts']);
            }
          });
        },
       
        (error: any) => {
          console.error('Login failed:', error);

          console.error('Login error:', error);
          // Extract error details
          const errorMessage = error.error?.message || 'An error occurred during login';
          const errorStatus = error.status || 500;
          const errorPath = error.error?.path || '';
    
         this.errorMessage = `Error: ${errorMessage}  (Status: ${errorStatus}, Path: ${errorPath})`;
    
          // Optionally show the error in a SweetAlert2 notification
          Swal.fire({
            title: "Error",
            text: this.errorMessage,
            icon: "error"
          });
        }
      );
    }
  }
}
