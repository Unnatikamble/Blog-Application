import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from 'src/app/Services/auth-service.service';
import { UserServiceService } from 'src/app/Services/user-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  user: any;
  userId: number = Number(localStorage.getItem("id"));
 //userId: number = 24;
 errorMessage: string | undefined;
 isVisible = false;

 constructor(private route: ActivatedRoute, private router: Router, private userService: UserServiceService,
   public authService: AuthServiceService) { }

 ngOnInit(): void {
   this.getUserDetails();
 }

  getUserDetails(): void {
   this.userService.getUserById(this.userId).subscribe(
     (data: any) => {
       this.user = data;
       console.log(data);
     },
     (error: any) => {
       this.errorMessage = 'Failed to retrieve user details. Please try again.';
     }
   );
  }

 openProfile() {
   this.isVisible = true;
   this.userId= Number(localStorage.getItem("id"));
   this.getUserDetails();
 }

 closeProfile() {
   this.isVisible = false;

 }

 

 logout() {
  Swal.fire({
    title: "Are you sure?",
    text: "Do You want to LogOut",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, LogOut"
  }).then((result) => {
    if (result.isConfirmed) {
     
      Swal.fire({
        title: "LogOut!",
        text: "LogOut SuccessFull.",
        icon: "success"
      }).then((result) => {
        if (result.isConfirmed) {
      this.isVisible = false;
      this.authService.logout();
        }
      });
    }
  });
   
 }

}
