import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDto } from 'src/app/Entities/user-dto';
import { UserServiceService } from 'src/app/Services/user-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  userForm!: FormGroup;

  constructor(private fb: FormBuilder, private userService: UserServiceService, private router: Router) {
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      about: ['']
    });
  }

  navigateToLogin() {
    this.router.navigate(['/user-registration/userLogin']);
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.userForm.valid) {
      const userDto: UserDto = this.userForm.value;
      this.userService.registerUser(userDto).subscribe(
        response => {
          console.log('User created successfully:', response);
          Swal.fire({
            title: "Registration",
            text: "User Registration-Successful!",
            icon: "success"
          }).then((result) => {
            if (result.isConfirmed) {
            this.router.navigate(['/user-registration/userLogin']);
            this.userForm.reset();
            }
        });
          
        },
        error => {
          const errorMessage = error.error;
          // this.errorMessage = `Error: ${errorMessage}`;
           Swal.fire({
             title: "Error",
             text: error.error,
             icon: "error"
           });
          console.error('Error creating user:', error);
        }
      );
    }
  }
}
