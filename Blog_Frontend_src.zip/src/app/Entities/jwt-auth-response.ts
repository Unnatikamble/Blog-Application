export interface JwtAuthResponse {
    id:number;
    token: string;
}
