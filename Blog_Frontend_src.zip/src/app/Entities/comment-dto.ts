export interface CommentDto {

    id?: number;
    content: string;
}
