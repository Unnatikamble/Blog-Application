export class CategoryDto {
    categoryId?: number;
    categoryTitle?: string;
    categoryDescription?: string;
  
    constructor(categoryId?: number, categoryTitle?: string, categoryDescription?: string) {
      this.categoryId = categoryId;
      this.categoryTitle = categoryTitle;
      this.categoryDescription = categoryDescription;
    }
  }
