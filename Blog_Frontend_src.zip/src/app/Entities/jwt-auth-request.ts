export interface JwtAuthRequest {
    
        username: string;
        password: string;
      }
      

