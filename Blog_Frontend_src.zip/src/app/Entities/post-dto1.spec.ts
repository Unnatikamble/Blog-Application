import { PostDto1 } from './post-dto1';

describe('PostDto1', () => {
  it('should create an instance', () => {
    expect(new PostDto1()).toBeTruthy();
  });
});
