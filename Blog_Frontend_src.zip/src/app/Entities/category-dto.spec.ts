import { CategoryDto } from './category-dto';

describe('CategoryDto', () => {
  it('should create an instance', () => {
    expect(new CategoryDto()).toBeTruthy();
  });
});
