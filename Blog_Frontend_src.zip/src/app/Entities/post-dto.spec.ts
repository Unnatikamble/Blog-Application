import { PostDto } from './post-dto';

describe('PostDto', () => {
  it('should create an instance', () => {
    expect(new PostDto()).toBeTruthy();
  });
});
