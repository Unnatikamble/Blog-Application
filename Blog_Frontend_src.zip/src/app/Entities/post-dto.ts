


export class PostDto {
    postId?: number;
    title?: string;
    content?: string;
    imageName?: string;
}