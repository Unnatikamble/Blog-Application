export class PostDto1 {
        postId?: number;
        title?: string;
        content?: string;
        imageName?:string;
       addedDate?:Date;
       
        constructor(
          postId?: number,
          title?: string,
          content?: string,
          imageName?: string, // Change this parameter to expect a byte array
          addedDate?: Date,
          
        ) {
          this.postId = postId;
          this.title = title;
          this.content = content;
          this.imageName = imageName; // Assign the photo byte array
          this.addedDate = addedDate;
        }
       
      }
     

