import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { PostDto } from '../Entities/post-dto';
import { PostDto1 } from '../Entities/post-dto1';

@Injectable({
  providedIn: 'root'
})
export class PostService {
 
  private apiUrl = 'http://localhost:8080'; // Base URL for the backend API

  constructor(private http: HttpClient) { }

  createPost(post: PostDto, userId: number, categoryId: number): Observable<PostDto> {
    return this.http.post<PostDto>(`${this.apiUrl}/api/user/${userId}/category/${categoryId}/posts`, post);
  }

  getAllPosts(): Observable<PostDto1[]> {
    // let tokenStr='Bearer '+localStorage.getItem('token');
    // const headers=new HttpHeaders().set('Authorization',tokenStr);
    return this.http.get<PostDto1[]>(`${this.apiUrl}/api/allPosts`);
  }

  updatePost(postId: number,post: PostDto1, ): Observable<PostDto1> {
    return this.http.put<PostDto1>(`${this.apiUrl}/api/posts/${postId}`, post);
  }

  // getPostById(postId: number): Observable<PostDto1> {
  //   return this.http.get<PostDto1>(`${this.apiUrl}api/posts/${postId}`);
  // }
  getPostById(postId: number): Observable<PostDto> {
    return this.http.get<PostDto>(`${this.apiUrl}/api/posts/${postId}`);
  }

  deletePost(postId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/api/posts/${postId}`);
  }

  getPostsByUser1(userId: number): Observable<PostDto1[]> {
    return this.http.get<PostDto1[]>(`${this.apiUrl}/api/user/${userId}/posts`);
  }

  getPostsByCategoryId1(categoryId: number): Observable<PostDto1[]> {
       return this.http.get<PostDto1[]>(`${this.apiUrl}/api/category/${categoryId}/posts`);
     }
    
}
