import { Injectable } from '@angular/core';
import { CommentDto } from '../Entities/comment-dto';
import { Observable } from 'rxjs/internal/Observable';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  private apiUrl = 'http://localhost:8080'; 

  constructor(private http: HttpClient) { }

  getCommentsByPostId(postId: number): Observable<CommentDto[]> {
    return this.http.get<CommentDto[]>(`${this.apiUrl}/api/comments/post/${postId}`);
  }

  addComment(comment: CommentDto,postId: number): Observable<CommentDto> {
    return this.http.post<CommentDto>(`${this.apiUrl}/api/comments/post/${postId}/comments`, comment);
  }

  deleteComment(commentId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/api/comments/Comments/${commentId}`);
  }
  
}