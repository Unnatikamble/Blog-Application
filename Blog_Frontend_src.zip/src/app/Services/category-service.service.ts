import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CategoryDto } from '../Entities/category-dto';
import { Observable } from 'rxjs/internal/Observable';
import { PostDto1 } from '../Entities/post-dto1';

@Injectable({
  providedIn: 'root'
})
export class CategoryServiceService {

  private apiUrl = 'http://localhost:8080'; // Adjust the URL as needed

  constructor(private http: HttpClient) {}

  createCategory(category: CategoryDto): Observable<CategoryDto> {
    return this.http.post<CategoryDto>(`${this.apiUrl}/api/categories/add`, category);
}


getCategories(): Observable<CategoryDto[]> {
  return this.http.get<CategoryDto[]>(`${this.apiUrl}/api/categories/getAll`);
}


// updateCategory(category: CategoryDto, categoryId: number): Observable<CategoryDto> {
//   return this.http.put<CategoryDto>(`${this.apiUrl}/api/categories/${categoryId}`, category);
// }

// updateCategory(category: CategoryDto, categoryId: number): Observable<CategoryDto> {
//   return this.http.put<CategoryDto>(`${this.apiUrl}/api/categories/${categoryId}`, category);
// }

updateCategory(category: CategoryDto, categoryId: number): Observable<CategoryDto> {
  return this.http.put<CategoryDto>(`${this.apiUrl}/api/categories/${categoryId}`, category);
}
getCategoryById(categoryId: number): Observable<CategoryDto> {
  return this.http.get<CategoryDto>(`${this.apiUrl}/api/categories/${categoryId}`);
}

deleteCategory(categoryId: number): Observable<void> {
  return this.http.delete<void>(`${this.apiUrl}/api/categories/${categoryId}`);
}

// getPostsByCategoryId1(categoryId: number): Observable<PostDto1[]> {
//   return this.http.get<PostDto1[]>(`${this.apiUrl}/posts/category/${categoryId}`);
// }

}
