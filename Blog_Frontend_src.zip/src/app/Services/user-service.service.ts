import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { UserDto } from '../Entities/user-dto';
import { HttpClient } from '@angular/common/http';
import { JwtAuthRequest } from '../Entities/jwt-auth-request';
import { JwtAuthResponse } from '../Entities/jwt-auth-response';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private apiUrl = 'http://localhost:8080'; // Adjust the URL as needed

  constructor(private http: HttpClient) {}

  registerUser(userDto: UserDto): Observable<UserDto> {
    return this.http.post<UserDto>(`${this.apiUrl}/api/v1/auth/register`, userDto);
}

login(username: string, password: string): Observable<JwtAuthResponse> {
  const request: JwtAuthRequest = { username, password };
  return this.http.post<JwtAuthResponse>(`${this.apiUrl}/api/v1/auth/login`, request);
}


getUserById(id: number): Observable<any> {
  // let tokenStr='Bearer '+localStorage.getItem('token');
  //   const headers=new HttpHeaders().set('Authorization',tokenStr);
  return this.http.get(`${this.apiUrl}/api/v1/auth/users/${id}`);
}
}
