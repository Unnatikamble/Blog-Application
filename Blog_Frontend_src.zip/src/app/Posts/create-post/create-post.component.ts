import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { PostDto } from 'src/app/Entities/post-dto';
import { PostService } from 'src/app/Services/post.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.css']
})
export class CreatePostComponent {

  post: PostDto = new PostDto();
  userId: number = Number(localStorage.getItem('id'))// Replace with actual user ID
  categoryId: number = 1; // Replace with actual category ID

  photoPreview: string | ArrayBuffer | null = null;
  createPostForm!: FormGroup;
  errorMessage: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private postService: PostService,
    private router: Router,
    private route:ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.categoryId = +this.route.snapshot.paramMap.get('categoryId')!;
    this.initializeForm();
  }

  initializeForm(): void {
    this.createPostForm = this.formBuilder.group({
      title: [''],
      content: [''],
      imageName: ['']
    });
  }

  addTouristGuide(): void {
    if (this.createPostForm.valid) {
      const newTouristGuide: PostDto = {
        title: this.createPostForm.value.title,
        content: this.createPostForm.value.content,
        imageName: this.createPostForm.value.imageName,
       
      };

      this.postService.createPost(newTouristGuide, this.userId, this.categoryId).subscribe(
        (response) => {
          console.log(response);

          Swal.fire({
            title: "Post Added",
            text: "Post Added-Successful!",
            icon: "success"
          }).then((result) => {
            if (result.isConfirmed) {
              // Navigate only if the user clicks "OK"
              this.router.navigate(['/user-registration/getAllPosts']);
            }
          });
        
        },
        (error) => {
          console.error('Error:', error);
          this.errorMessage = 'Failed to add tourist guide. Please try again.';
          console.error('Login failed:', error);

          console.error('Login error:', error);
          // Extract error details
          const errorMessage = error.error?.message || 'An error occurred during login';
          const errorStatus = error.status || 500;
          const errorPath = error.error?.path || '';
    
         this.errorMessage = `Error: ${errorMessage}  (Status: ${errorStatus}, Path: ${errorPath})`;
    
          // Optionally show the error in a SweetAlert2 notification
          Swal.fire({
            title: "Error",
            text: this.errorMessage,
            icon: "error"
          });
        }
      );
    }
  }

  onPhotoSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64Image = reader.result as string;
        const uint8Array = new Uint8Array(atob(base64Image.split(',')[1]).split('').map(char => char.charCodeAt(0)));
        const imageData = this.uint8ArrayToBase64(uint8Array);
        this.photoPreview = base64Image;
        this.createPostForm.patchValue({ imageName: imageData }); // Corrected the control name to "photo"
        this.createPostForm.get('imageName')?.updateValueAndValidity(); // Update form control validity
      };
    }
  }
 
  uint8ArrayToBase64(uint8Array: Uint8Array): string {
    let binary = '';
    for (let i = 0; i < uint8Array.length; i++) {
      binary += String.fromCharCode(uint8Array[i]);
    }
    return window.btoa(binary);
  }
}