import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommentDto } from 'src/app/Entities/comment-dto';
import { PostDto1 } from 'src/app/Entities/post-dto1';
import { CommentService } from 'src/app/Services/comment.service';
import { PostService } from 'src/app/Services/post.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
  

 
postDetails: PostDto1 = {};
  comments: CommentDto[] = [];
  errorMessage: string = '';
  commentForm: FormGroup;

  postId: number = 0;

  constructor(
    private postService: PostService,
    private commentService: CommentService,
    private router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder
  ) {
    this.commentForm = this.fb.group({
      content: ['', Validators.required]
    });
  }
 
  ngOnInit(): void {
    this.postId = +this.route.snapshot.paramMap.get('postId')!;
    this.getPostById();
    this.getComments();
  }

  getPostById(): void {
    this.postService.getPostById(this.postId)
      .subscribe(
        (data) => {
          this.postDetails = data;
          this.convertPhotos();
        },
        (error) => {
          this.errorMessage = 'Failed to retrieve tourist guides. Please try again.';
        }
      );
  }

  convertPhotos(): void {
    if (this.postDetails.imageName) {
      this.postDetails.imageName = 'data:image/jpeg;base64,' + this.postDetails.imageName;
    }
  }

  getComments(): void {
    this.commentService.getCommentsByPostId(this.postId)
      .subscribe(
        (data) => {
          this.comments = data;
        },
        (error) => {
          console.error('Failed to retrieve comments', error);
        }
      );
  }

  onSubmit(): void {
    if (this.commentForm.valid) {
      const newComment: CommentDto = {
        content: this.commentForm.value.content
      };
      this.commentService.addComment(newComment, this.postId)
        .subscribe(
          (data) => {
           // this.comments.push(data);
           this.getComments();
           Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Comment Added successfully",
            showConfirmButton: false,
            timer: 1500
          });
            this.commentForm.reset();
          },
          (error) => {
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: "unable to add comment",
              showConfirmButton: false,
              timer: 1500
            });
            console.error('Failed to add comment', error);
          }
        );
    }
  }

  deleteComment(commentId: number): void {
    this.commentService.deleteComment(commentId)
      .subscribe(
        () => {
          this.comments = this.comments.filter(comment => comment.id !== commentId);

          Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Comment deleted succesffully",
            showConfirmButton: false,
            timer: 1500
          });
        },
        (error) => {
          console.error('Failed to delete comment', error);
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: "Unable to delete the comment",
            showConfirmButton: false,
            timer: 1500
          });
        }
      );
  }}