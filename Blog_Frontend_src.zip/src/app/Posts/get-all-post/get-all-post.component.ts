import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PostDto1 } from 'src/app/Entities/post-dto1';
import { PostService } from 'src/app/Services/post.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-get-all-post',
  templateUrl: './get-all-post.component.html',
  styleUrls: ['./get-all-post.component.css']
})
export class GetAllPostComponent implements OnInit {

  posts: PostDto1[] = [];
  errorMessage: string = '';
  pageSize = 6;
  currentPage = 1;
  totalPages: number[] = [];
 userId:number=0;
 
 //userId:number=1;
  constructor(private postService: PostService, private router: Router) { }
 
  ngOnInit(): void {
    this.userId=Number(localStorage.getItem('id'));
    console.log(this.userId);
    this.getAllPosts();
   
  }


 
  getAllPosts(): void {
    // this.touristGuideService.getAllPosts()
    //   .subscribe(
    //     (data) => {
    //       this.touristGuides = data;
    //       console.log(this.touristGuides);
    this.postService.getPostsByUser1(this.userId)
    .subscribe(
      (data) => {

      this.posts = data;
       console.log(this.posts);
     
          this.convertPhotos(); // Convert photos to base64
          this.calculateTotalPages(); // Calculate total pages
         
        },
        (error) => {
          this.errorMessage = 'Failed to retrieve posts . Please try again.';
        }
      );
  }
 
 
  convertPhotos(): void {
    this.posts.forEach(guide => {
      if (guide.imageName) {
        guide.imageName = 'data:image/jpeg;base64,' + guide.imageName;
      }
    });
  }
 
    navigateToUpdate(postId?: number): void {
      console.log("postId",postId);
      this.router.navigate(['/user-registration/updatePost',postId]);
  }
 
 viewPost(postId?:number):void{
  console.log("postissview",postId)
  this.router.navigate(['/user-registration/post',postId]);
 }

  calculateTotalPages(): void {
    const pageCount = Math.ceil(this.posts.length / this.pageSize);
    this.totalPages = Array.from({ length: pageCount }, (_, i) => i + 1);
  }
 
  changePage(page: number): void {
    this.currentPage = page;
  }


  deletePost1(postId: number | undefined) {
    if (postId === undefined) {
      console.error('Category ID is undefined');
      return;
    }
 
const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger"
      },
      buttonsStyling: false
    });
    swalWithBootstrapButtons.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
         this.postService.deletePost(postId).subscribe(
      response => {
        console.log('Category deleted:', response);      
        swalWithBootstrapButtons.fire({
            title: "Deleted!",
            text: "Your file has been deleted.",
            icon: "success"
          }).then((res => {
            this.getAllPosts(); 
          }));
        },
        (error) => {
          Swal.fire({
            title: "Error in deleting file",
            text: error.error,
            icon: "error"
          });
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        swalWithBootstrapButtons.fire({
          title: "Cancelled",
          text: "Your imaginary file is safe :)",
          icon: "error"
        });
      }
    });
}
}
 


