import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryDto } from 'src/app/Entities/category-dto';
import { CommentDto } from 'src/app/Entities/comment-dto';
import { PostDto1 } from 'src/app/Entities/post-dto1';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import { CommentService } from 'src/app/Services/comment.service';
import { PostService } from 'src/app/Services/post.service';

@Component({
  selector: 'app-all-users-posts',
  templateUrl: './all-users-posts.component.html',
  styleUrls: ['./all-users-posts.component.css']
})
export class AllUsersPostsComponent implements OnInit {

posts: PostDto1[] = [];
  errorMessage: string = '';
  pageSize = 6;
  currentPage = 1;
  totalPages: number[] = [];
  categories: CategoryDto[] = []; // Array to hold categories
  likedPosts: number[] = []; // Array to track liked posts
  commentForm: FormGroup;
  showAllComments: { [key: number]: boolean } = {}; // Track show/hide state per postId
  commentsMap: { [key: number]: CommentDto[] } = {};
  displayedCommentsMap: { [key: number]: CommentDto[] } = {};

  constructor(
    private postService: PostService,
    private router: Router,
    private commentService: CommentService,private categoryService: CategoryServiceService,
    private fb: FormBuilder
  ) {
    this.commentForm = this.fb.group({
      content: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.getAllCategories();
    this.loadCategories(); // Call method to load categories

  }

  getAllCategories(): void {
    this.postService.getAllPosts().subscribe(
      (data) => {
        this.posts = data;
        this.convertPhotos();
        this.calculateTotalPages();
        this.posts.forEach(guide => this.getComments(guide.postId || 0));
      },
      (error) => {
        this.errorMessage = 'Failed to retrieve tourist guides. Please try again.';
      }
    );
  }

  loadCategories() {
    this.categoryService.getCategories().subscribe(
      data => {
        this.categories = data;
      },
      error => console.log(error)
    );
  }

  convertPhotos(): void {
    this.posts.forEach(guide => {
      if (guide.imageName) {
        guide.imageName = 'data:image/jpeg;base64,' + guide.imageName;
      }
    });
  }

  getComments(postId: number): void {
    this.commentService.getCommentsByPostId(postId).subscribe(
      (data) => {
        this.commentsMap[postId] = data;
        this.updateDisplayedComments(postId);
      },
      (error) => {
        console.error('Failed to retrieve comments', error);
      }
    );
  }

  updateDisplayedComments(postId: number): void {
    const comments = this.commentsMap[postId] || [];
    this.displayedCommentsMap[postId] = this.showAllComments[postId] ? comments : comments.slice(-1);
    
  }

  toggleComments(postId: number): void {
    this.showAllComments[postId] = !this.showAllComments[postId];
    this.updateDisplayedComments(postId);
  }

  onSubmit(postId: number): void {
    if (this.commentForm.valid) {
      const newComment: CommentDto = {
        content: this.commentForm.value.content
      };
      this.commentService.addComment(newComment, postId).subscribe(
        (data) => {
          this.getComments(postId);
          this.commentForm.reset();
        },
        (error) => {
          console.error('Failed to add comment', error);
        }
      );
    }
  }

  deleteComment(commentId: number, postId: number): void {
    this.commentService.deleteComment(commentId).subscribe(
      () => {
        this.commentsMap[postId] = this.commentsMap[postId].filter(comment => comment.id !== commentId);
        this.updateDisplayedComments(postId);
      },
      (error) => {
        console.error('Failed to delete comment', error);
      }
    );
  }

  calculateTotalPages(): void {
    const pageCount = Math.ceil(this.posts.length / this.pageSize);
    this.totalPages = Array.from({ length: pageCount }, (_, i) => i + 1);
  }

  changePage(page: number): void {
    this.currentPage = page;
  }

  navigateToUpdate(postId?: number): void {
    console.log('postId', postId);
    this.router.navigate(['updatePost', postId]);
  }

  navigateToAddTours(touristGuideId?: number): void {
    if (touristGuideId !== undefined) {
      this.router.navigate(['admin-registration/adminTouristGuides/addTours', touristGuideId]);
    }
  }

  viewPost(postId?: number): void {
    console.log('postId', postId);
    this.router.navigate(['post', postId]);
  }

  navigateToGetPostById(id?: number): void {
    if (id !== undefined) {
      this.router.navigate(['admin-registration/adminTouristGuides/adminTours', id]);
    }
  }


  filterPostsByCategory(categoryId: number): void {
    this.postService.getPostsByCategoryId1(categoryId).subscribe(
      (data) => {
        this.posts = data;
        this.convertPhotos();
        this.calculateTotalPages();
        this.posts.forEach(guide => this.getComments(guide.postId || 0));
      },
      (error) => {
        this.errorMessage = 'Failed to retrieve posts. Please try again.';
      }
    );
  }

  likePost(postId: number) {
    console.log(`Post with ID ${postId} liked.`);
    // Add your like functionality here if needed.
  }
  toggleLike(postId: number) {
    if (this.likedPosts.includes(postId)) {
      this.likedPosts = this.likedPosts.filter(id => id !== postId);
    } else {
      this.likedPosts.push(postId);
    }
  }
}