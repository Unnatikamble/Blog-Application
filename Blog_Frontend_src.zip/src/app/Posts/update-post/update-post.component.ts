
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PostDto1 } from 'src/app/Entities/post-dto1';
import { PostService } from 'src/app/Services/post.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-post',
  templateUrl: './update-post.component.html',
  styleUrls: ['./update-post.component.css']
})
export class UpdatePostComponent implements OnInit {

  posts: PostDto1[] = [];
  postForm!: FormGroup;
  errorMessage: string = '';
  photoPreview: string | ArrayBuffer | null = null;
  postId: number = 2; // Variable to store touristGuideId

  constructor(
    private formBuilder: FormBuilder,
    private postService: PostService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.postId = +this.route.snapshot.paramMap.get('postId')!;
    this.getTouristGuideDetails(this.postId);
  }

  initializeForm(): void {
    this.postForm = this.formBuilder.group({
      title: ['', Validators.required],
      content: ['', Validators.required],
      imageName: [''], // Note: No validators as it may be optional
      // addedDate: ['',Validators.required]
    });
  }

  getTouristGuideDetails(postId: number): void {
    this.postService.getPostById(postId).subscribe(
      (touristGuide: PostDto1) => {
        this.postForm.patchValue({
          title: touristGuide.title,
          content: touristGuide.content,
          addedDate: touristGuide.addedDate
        });
        if (touristGuide.imageName) {
          this.photoPreview = 'data:image/jpeg;base64,' + touristGuide.imageName;
          this.postForm.patchValue({ imageName: touristGuide.imageName });
        }
      },
      error => {
        this.errorMessage = 'Failed to retrieve tour details';
      }
    );
  }

  onPhotoSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64Image = reader.result as string;
        const uint8Array = new Uint8Array(atob(base64Image.split(',')[1]).split('').map(char => char.charCodeAt(0)));
        const imageData = this.uint8ArrayToBase64(uint8Array);
        this.photoPreview = base64Image;
        this.postForm.patchValue({ imageName: imageData });
        this.postForm.get('imageName')?.updateValueAndValidity();
      };
    }
  }

  uint8ArrayToBase64(uint8Array: Uint8Array): string {
    let binary = '';
    for (let i = 0; i < uint8Array.length; i++) {
      binary += String.fromCharCode(uint8Array[i]);
    }
    return window.btoa(binary);
  }

  updateTouristGuide(): void {
    if (this.postForm.valid) {
      const updatedPostDto1: PostDto1 = {
        title: this.postForm.value.title,
        content: this.postForm.value.content,
        imageName: this.postForm.value.imageName,
        // addedDate: this.touristGuideForm.value.addedDate
      };

       Swal.fire({
        title: "Do you want to save the changes?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Save",
        denyButtonText: `Don't save`
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) { 

       this.postService.updatePost(this.postId, updatedPostDto1).subscribe(
        () => {
          console.log('Tourist guide updated successfully');      
          Swal.fire("Changes Updated Successfully!", "", "success").then((res=>{
             this.router.navigate(['/user-registration/getAllPosts']);
          }));
        },
        error => {
          Swal.fire({
            title: "Error",
            text: error.error,
            icon: "error"
          });
               this.errorMessage = 'Failed to update tour. Please try again.';
             }
           );
        } else if (result.isDenied) {
          Swal.fire("Changes are not Updated", "", "info");
        }
      });
    }
  }
}
