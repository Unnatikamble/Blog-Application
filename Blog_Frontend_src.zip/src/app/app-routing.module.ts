import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserLoginComponent } from './Users/user-login/user-login.component';
import { RegisterUserComponent } from './Users/register-user/register-user.component';
import { AddCategoryComponent } from './Categories/add-category/add-category.component';
import { UpdateCategoryComponent } from './Categories/update-category/update-category.component';
import { GetAllCategoryComponent } from './Categories/get-all-category/get-all-category.component';
import { CreatePostComponent } from './Posts/create-post/create-post.component';
import { GetAllPostComponent } from './Posts/get-all-post/get-all-post.component';
import { UpdatePostComponent } from './Posts/update-post/update-post.component';
import { PostDetailsComponent } from './Posts/post-details/post-details.component';
import { DashboardComponent } from './Dashboards/dashboard/dashboard.component';
import { AboutUsComponent } from './Dashboards/about-us/about-us.component';
import { UserDashboardComponent } from './Dashboards/user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './Dashboards/admin-dashboard/admin-dashboard.component';
import { AllUsersPostsComponent } from './Posts/all-users-posts/all-users-posts.component';

const routes: Routes = [
  // { path: '', redirectTo: 'userRegister', pathMatch: 'full' },

  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {path: 'home', component: DashboardComponent,},
  { path: 'aboutus', component: AboutUsComponent},

  //USER-DASHBOARD
   { path: 'user-registration', component:UserDashboardComponent,
   children: [
    { path: '', redirectTo: 'userRegister', pathMatch: 'full' } ,
     {path:'userRegister',component:RegisterUserComponent,},
     {path:'userLogin',component:UserLoginComponent,},
     {path:'AllUsersPosts',component:AllUsersPostsComponent},
     {path:'addCategory',component:AddCategoryComponent},
  {path:'updateCategory/:categoryId',component:UpdateCategoryComponent},
  {path:'getAllCategory',component:GetAllCategoryComponent},
  {path:'createPost/:categoryId',component:CreatePostComponent},
  {path:'getAllPosts',component:GetAllPostComponent},
  { path: 'updatePost/:postId', component: UpdatePostComponent },
  { path: 'post/:postId', component: PostDetailsComponent }
   ]},

//ADMIN-DASHBOARD
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }