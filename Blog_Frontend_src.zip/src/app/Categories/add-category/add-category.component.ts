import { Component, OnInit } from '@angular/core';
import { CategoryDto } from 'src/app/Entities/category-dto';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import { NgModule } from '@angular/core';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent {

  category: CategoryDto = new CategoryDto();
  submitted = false;

  constructor(private categoryService: CategoryServiceService) { }

  saveCategory() {
    this.categoryService.createCategory(this.category).subscribe(
      data => {
        console.log(data);
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Category Added Successfully",
          showConfirmButton: false,
          timer: 1500
        });
        this.submitted = true;
      },
      error => console.log(error)
    );
  }

  newCategory() {
    this.submitted = false;
    this.category = new CategoryDto();
  }
}