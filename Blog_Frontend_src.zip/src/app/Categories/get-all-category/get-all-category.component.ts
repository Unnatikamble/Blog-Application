import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryDto } from 'src/app/Entities/category-dto';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-get-all-category',
  templateUrl: './get-all-category.component.html',
  styleUrls: ['./get-all-category.component.css']
})
export class GetAllCategoryComponent implements OnInit {
  

  
  

  categories: CategoryDto[] = [];

  constructor(private categoryService: CategoryServiceService,
    private router: Router) { }

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories() {
    this.categoryService.getCategories().subscribe(
      data => {
        this.categories = data;
      },
      error => console.log(error)
    );
  }

  editCategory(categoryId: number | undefined) {
    if (categoryId === undefined) {
      console.error('Category ID is undefined');
      return;
    }
    // Implement edit logic here, such as navigating to an edit form with the category data
    console.log('Edit category ID:', categoryId);
    this.router.navigate(['/user-registration/updateCategory',categoryId])
  }


  

  deleteCategory(categoryId: number | undefined) {
    if (categoryId === undefined) {
      console.error('Category ID is undefined');
      return;
    } 

const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger"
      },
      buttonsStyling: false
    });
    swalWithBootstrapButtons.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
         this.categoryService.deleteCategory(categoryId).subscribe(
      response => {
        console.log('Category deleted:', response);        
          swalWithBootstrapButtons.fire({
            title: "Deleted!",
            text: "Your file has been deleted.",
            icon: "success"
          }).then((res => {
            this.loadCategories();
          }));
        },
        (error) => {
          Swal.fire({
            title: "Error in deleting file",
            text: error.error,
            icon: "error"
          });
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        swalWithBootstrapButtons.fire({
          title: "Cancelled",
          text: "Your imaginary file is safe :)",
          icon: "error"
        });
      }
    });
}



  AddPost(categoryId: number | undefined){
    
    this.router.navigate(['/user-registration/createPost',categoryId])

  }
  
}