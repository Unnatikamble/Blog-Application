import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryDto } from 'src/app/Entities/category-dto';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit  {

  category: CategoryDto | undefined;
  errorMessage:string='';
  constructor(
    private route: ActivatedRoute,
    private categoryService: CategoryServiceService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // this.route.params.subscribe(params => {
    //   const id = +params['categoryId']; 
    const id=+this.route.snapshot.paramMap.get('categoryId')!;
    console.log(id);

    this.cat(id);
      
  }
cat(id:number){
  this.categoryService.getCategoryById(id).subscribe(
    (data: CategoryDto) => {
      this.category = data;
    },
    error => console.log(error)
  );
}

  

  onSubmit() {
   
      Swal.fire({
        title: "Do you want to save the changes?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Save",
        denyButtonText: `Don't save`
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) { 
          if (this.category && this.category.categoryId) {
      this.categoryService.updateCategory(this.category, this.category.categoryId).subscribe(
        data => {
          console.log('Category updated successfully');      
           Swal.fire("Changes Updated Successfully!", "", "success").then((res=>{
            this.router.navigate(['/user-registration/getAllCategory']);
          }));
        },
        error => {
          Swal.fire({
            title: "Error",
            text: error.error,
            icon: "error"
          });
               this.errorMessage = 'Failed to update tour. Please try again.';
             }
           );
        } else if (result.isDenied) {
          Swal.fire("Changes are not Updated", "", "info");
        }
  }});
    }
  }