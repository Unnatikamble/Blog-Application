import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BlogApplicationApis';

  

  constructor(private router: Router) {}

  isAdminRegistrationRoute(): boolean {
    return this.router.url === '/admin-registration';
  }

  isUserRegistrationRoute(): boolean {
    return this.router.url === '/user-registration';
  }
  
}
