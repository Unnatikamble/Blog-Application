import { CUSTOM_ELEMENTS_SCHEMA,NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './Users/register-user/register-user.component';
import { UserLoginComponent } from './Users/user-login/user-login.component';
import { AddCategoryComponent } from './Categories/add-category/add-category.component';
import { UpdateCategoryComponent } from './Categories/update-category/update-category.component';
import { GetAllCategoryComponent } from './Categories/get-all-category/get-all-category.component';
import { CreatePostComponent } from './Posts/create-post/create-post.component';
import { GetAllPostComponent } from './Posts/get-all-post/get-all-post.component';
import { PaginatePipe } from './pipes/paginate.pipe';
import { UpdatePostComponent } from './Posts/update-post/update-post.component';

import { PostDetailsComponent } from './Posts/post-details/post-details.component';
import { DashboardComponent } from './Dashboards/dashboard/dashboard.component';
import { AdminDashboardComponent } from './Dashboards/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './Dashboards/user-dashboard/user-dashboard.component';
import { AboutUsComponent } from './Dashboards/about-us/about-us.component';
import { UserProfileComponent } from './Users/user-profile/user-profile.component';
import { DatePipe } from '@angular/common';
import { AllUsersPostsComponent } from './Posts/all-users-posts/all-users-posts.component';
// import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';



@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    UserLoginComponent,
    AddCategoryComponent,
    UpdateCategoryComponent,
    GetAllCategoryComponent,
    CreatePostComponent,
    GetAllPostComponent,
    PaginatePipe,
    UpdatePostComponent,
    PostDetailsComponent,
    DashboardComponent,
    AdminDashboardComponent,
    UserDashboardComponent,
    AboutUsComponent,
    UserProfileComponent,
    AllUsersPostsComponent
  
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule, // Add this line
    HttpClientModule,
    // SweetAlert2Module.forRoot()
    

  ],
  providers: [
   // provideClientHydration(),
    DatePipe
  ],
  bootstrap: [AppComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
