package com.blog.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.Test;
import com.blog.payloads.ApiResponse;
import com.blog.payloads.CategoryDto;
import com.blog.payloads.CommentDto;
import com.blog.payloads.JwtAuthRequest;
import com.blog.payloads.JwtAuthResponse;
import com.blog.payloads.PostDto;
import com.blog.payloads.PostResponse;
import com.blog.payloads.UserDto;
import javax.validation.Validator;

public class DtoTest {
	
//	private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
//	private final Validator validator = factory.getValidator();
//	
//	@Test
//	public void testUserDto() {
//		UserDto userDto = new UserDto();
//		userDto.setId(7);
//		userDto.setName("Misba");
//		userDto.setPassword("rmskd");
//		userDto.setEmail("misbamorve25@gmail.com");
//		userDto.setAbout("I am react developer");
//		Set<String> violations = validateAndGetViolations(userDto);
//		assertThat(userDto).isNotNull();
//		
//	}
//	
//	@Test
//	public void testCategoryDto() {
//		
//		CategoryDto categoryDto = new CategoryDto();
//		categoryDto.setCategoryId(8);
//		categoryDto.setCategoryTitle("politics");
//		categoryDto.setCategoryDescription("this site contains policatics related topics");
//		Set<String> violations = validateAndGetViolations(categoryDto);
//		assertThat(categoryDto).isNotNull();
//		
//	}
//	
//	  @Test 
//	  public void testApiResponseValidation() {
//	  
//	  ApiResponse apiResponse = new ApiResponse();
//	  apiResponse.setMessage("Api Response is succesfull");
//	  apiResponse.isSuccess(); 
//	  Set<String> violations =validateAndGetViolations(apiResponse); 
//	  assertThat(apiResponse).isNotNull();
//	  
//	  }
//	  
//	  @Test
//	  public void testCommentDto() {
//		  
//		  CommentDto commentDto = new CommentDto();
//		  commentDto.setId(1);
//		  commentDto.setContent("this nice blog");
//		  Set<String> violations =validateAndGetViolations(commentDto); 
//		  assertThat(commentDto).isNotNull();
//		  
//	  }
//	  
//	  @Test
//	  public void testPostDto() {
//		  
//		  PostDto postDto = new PostDto();
//		  postDto.setPostId(2);
//		  postDto.setTitle("PostTitle");
//		  postDto.setImageName("image.jpeg");
//		  postDto.setContent("this is image");
//		  postDto.setAddedDate(LocalDate.of(2024,02,12));
//		  Set<String> violations =validateAndGetViolations(postDto); 
//		  assertThat(postDto).isNotNull();
//		  
//	  }
//	  
//	  @Test
//	  public void testPostResponse() {
//		  
//		  PostResponse postResponse = new PostResponse();
//		  postResponse.setTotalPages(10);
//		  postResponse.setTotalElements(12238);
//		  postResponse.setPageSize(5);
//		  postResponse.setPageNumber(0);
//		  postResponse.setLastPage(true);
//		 
//		 // Set<String> violations =validateAndGetViolations(postResponse); 
//		  assertThat(postResponse).isNotNull();
//
//	  }
//	  
//	  @Test
//	  public  void testJwtAuthRequest() {
//		  
//		  JwtAuthRequest jwtAuthRequest = new JwtAuthRequest();
//		  jwtAuthRequest.setUsername("username");
//		  jwtAuthRequest.setPassword("128ahnn");
//		  assertThat(jwtAuthRequest).isNotNull();
//		  
//	  }
//	  
//	  @Test
//	  public void testJwtAuthResponse() {
//		  JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
//		  jwtAuthResponse.setToken("eoydhedjdjwkikmd");
//		  assertThat(jwtAuthResponse).isNotNull();
//		  
//		  
//		 
//		  
//	  }
//	  
//	 
//	  
//	  private <T> Set<String> validateAndGetViolations(T object) {
//			
//		  Set<String> violations = new HashSet<>();
//			validator.validate(object).forEach(violation -> {
//				violations.add(violation.getPropertyPath() + " " + violation.getMessage());
//			});
//			return violations;
//		}
//	 
//	
//	
	

}
