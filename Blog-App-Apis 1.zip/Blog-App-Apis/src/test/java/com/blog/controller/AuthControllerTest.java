package com.blog.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;

import com.blog.payloads.UserDto;

import com.blog.security.JwtTokenHelper;
import com.blog.service.UserService;
import com.blog.serviceimpl.UserServiceImpl;

public class AuthControllerTest {

	@InjectMocks
	private AuthController authController;

	@Mock
	private AuthenticationManager authenticationManager;

	@Mock
	private UserService userService;

	@Mock
	private JwtTokenHelper jwtTokenHelper;

	@Mock
	private UserServiceImpl userServiceImple;

	@Mock
	private ModelMapper modelMapper;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testRegisterUser() {

		UserDto userDto = new UserDto();
		userDto.setId(1);
		userDto.setName("Unnati");
		userDto.setPassword("urk1996");
		userDto.setEmail("unnati10k@gmail.com");
		userDto.setAbout("i am java developer");

		when(modelMapper.map(userDto, UserDto.class)).thenReturn(userDto);
		when(userService.registerNewUser(userDto)).thenReturn(userDto);

		ResponseEntity<UserDto> response = authController.registerUser(userDto);

		assertThat(response.getStatusCode());
		assertThat(response.getBody());

	}
}
