package com.blog.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.blog.entity.Comment;
import com.blog.entity.Post;
import com.blog.exception.ResourceNotFoundException;
import com.blog.payloads.CommentDto;
import com.blog.repository.CommentRepo;
import com.blog.repository.PostRepo;
import com.blog.serviceimpl.CommentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Optional;

public class CommentServiceImplTest {

    @InjectMocks
    private CommentServiceImpl commentService;

    @Mock
    private PostRepo postRepo;

    @Mock
    private CommentRepo commentRepo;

    @Mock
    private ModelMapper modelMapper;

    private Comment comment;
    private CommentDto commentDto;
    private Post post;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        post = new Post();
        post.setPostId(1);
        post.setTitle("Test Post");

        comment = new Comment();
        comment.setId(1);
        comment.setContent("Test Comment");
        comment.setPost(post);

        commentDto = new CommentDto();
        commentDto.setId(1);
        commentDto.setContent("Test Comment");
    }

    @Test
    public void testCreateComment() {
        when(postRepo.findById(anyInt())).thenReturn(Optional.of(post));
        when(modelMapper.map(any(CommentDto.class), eq(Comment.class))).thenReturn(comment);
        when(commentRepo.save(any(Comment.class))).thenReturn(comment);
        when(modelMapper.map(any(Comment.class), eq(CommentDto.class))).thenReturn(commentDto);

        CommentDto createdComment = commentService.createComment(commentDto, 1);

        assertNotNull(createdComment);
        assertEquals(commentDto.getContent(), createdComment.getContent());
        verify(postRepo, times(1)).findById(anyInt());
        verify(commentRepo, times(1)).save(any(Comment.class));
    }

    @Test
    public void testCreateComment_PostNotFound() {
        when(postRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> commentService.createComment(commentDto, 1));
        verify(postRepo, times(1)).findById(anyInt());
    }

    @Test
    public void testDeleteComment() {
        when(commentRepo.findById(anyInt())).thenReturn(Optional.of(comment));
        doNothing().when(commentRepo).delete(any(Comment.class));

        commentService.deleteComment(1);

        verify(commentRepo, times(1)).findById(anyInt());
        verify(commentRepo, times(1)).delete(any(Comment.class));
    }

    @Test
    public void testDeleteComment_CommentNotFound() {
        when(commentRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> commentService.deleteComment(1));
        verify(commentRepo, times(1)).findById(anyInt());
    }
}
