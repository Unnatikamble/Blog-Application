package com.blog.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.blog.entity.User;
import com.blog.entity.Role;
import com.blog.payloads.UserDto;
import com.blog.repository.RoleRepo;
import com.blog.repository.UserRepo;
import com.blog.serviceimpl.UserServiceImpl;
import com.blog.exception.ResourceNotFoundException;
import com.blog.config.AppConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

public class UserServiceImplTest {

	@InjectMocks
	private UserServiceImpl userService;

	@Mock
	private UserRepo userRepo;

	@Mock
	private ModelMapper modelMapper;

	@Mock
	private PasswordEncoder passwordEncoder;

	@Mock
	private RoleRepo roleRepo;

	private User user;
	private UserDto userDto;
	private Role role;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);

		user = new User();
		user.setId(1);
		user.setName("John Doe");
		user.setEmail("john.doe@example.com");
		user.setPassword("password123");
		user.setAbout("About John Doe");

		userDto = new UserDto();
		userDto.setId(1);
		userDto.setName("John Doe");
		userDto.setEmail("john.doe@example.com");
		userDto.setPassword("password123");
		userDto.setAbout("About John Doe");

		role = new Role();
		role.setId(AppConstants.NORMAL_USER);
		role.setName("ROLE_USER");
	}

	@Test
	    public void testCreateUser() {
	        when(modelMapper.map(any(UserDto.class), eq(User.class))).thenReturn(user);
	        when(userRepo.save(any(User.class))).thenReturn(user);
	        when(modelMapper.map(any(User.class), eq(UserDto.class))).thenReturn(userDto);

	        UserDto createdUser = userService.createUser(userDto);

	        assertNotNull(createdUser);
	        assertEquals(userDto.getName(), createdUser.getName());
	        verify(userRepo, times(1)).save(any(User.class));
	    }

	@Test
	    public void testUpdateUser() {
	        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
	        when(userRepo.save(any(User.class))).thenReturn(user);
	        when(modelMapper.map(any(User.class), eq(UserDto.class))).thenReturn(userDto);

	        UserDto updatedUser = userService.updateUser(userDto, 1);

	        assertNotNull(updatedUser);
	        assertEquals(userDto.getName(), updatedUser.getName());
	        verify(userRepo, times(1)).findById(anyInt());
	        verify(userRepo, times(1)).save(any(User.class));
	    }

	@Test
	    public void testGetUserById() {
	        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
	        when(modelMapper.map(any(User.class), eq(UserDto.class))).thenReturn(userDto);

	        UserDto foundUser = userService.getUserById(1);

	        assertNotNull(foundUser);
	        assertEquals(userDto.getName(), foundUser.getName());
	        verify(userRepo, times(1)).findById(anyInt());
	    }

	@Test
	public void testGetAllUsers() {
		List<User> users = Arrays.asList(user);
		List<UserDto> userDtos = Arrays.asList(userDto);

		when(userRepo.findAll()).thenReturn(users);
		when(modelMapper.map(any(User.class), eq(UserDto.class))).thenReturn(userDto);

		List<UserDto> allUsers = userService.getAllUsers();

		assertNotNull(allUsers);
		assertEquals(1, allUsers.size());
		verify(userRepo, times(1)).findAll();
	}

	@Test
	    public void testDeleteUser() {
	        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
	        doNothing().when(userRepo).delete(any(User.class));

	        userService.deleteUser(1);

	        verify(userRepo, times(1)).findById(anyInt());
	        verify(userRepo, times(1)).delete(any(User.class));
	    }

	@Test
	    public void testRegisterNewUser() {
	        when(modelMapper.map(any(UserDto.class), eq(User.class))).thenReturn(user);
	        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
	        when(roleRepo.findById(anyInt())).thenReturn(Optional.of(role));
	        when(userRepo.save(any(User.class))).thenReturn(user);
	        when(modelMapper.map(any(User.class), eq(UserDto.class))).thenReturn(userDto);

	        UserDto registeredUser = userService.registerNewUser(userDto);

	        assertNotNull(registeredUser);
	        assertEquals(userDto.getName(), registeredUser.getName());
	        verify(userRepo, times(1)).save(any(User.class));
	        verify(passwordEncoder, times(1)).encode(anyString());
	        verify(roleRepo, times(1)).findById(anyInt());
	    }

	@Test
	    public void testGetUserById_UserNotFound() {
	        when(userRepo.findById(anyInt())).thenReturn(Optional.empty());

	        assertThrows(ResourceNotFoundException.class, () -> userService.getUserById(1));
	        verify(userRepo, times(1)).findById(anyInt());
	    }
}
