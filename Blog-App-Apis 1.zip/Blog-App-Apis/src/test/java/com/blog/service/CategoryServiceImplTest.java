package com.blog.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.blog.entity.Category;
import com.blog.exception.ResourceNotFoundException;
import com.blog.payloads.CategoryDto;
import com.blog.repository.CategoryRepo;
import com.blog.serviceimpl.CategoryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CategoryServiceImplTest {

    @InjectMocks
    private CategoryServiceImpl categoryService;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private ModelMapper modelMapper;

    private Category category;
    private CategoryDto categoryDto;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        category = new Category();
        category.setCategoryId(1);
        category.setCategoryTitle("Technology");
        category.setCategoryDescription("All about technology");

        categoryDto = new CategoryDto();
        categoryDto.setCategoryId(1);
        categoryDto.setCategoryTitle("Technology");
        categoryDto.setCategoryDescription("All about technology");
    }

    @Test
    public void testCreateCategory() {
        when(modelMapper.map(any(CategoryDto.class), eq(Category.class))).thenReturn(category);
        when(categoryRepo.save(any(Category.class))).thenReturn(category);
        when(modelMapper.map(any(Category.class), eq(CategoryDto.class))).thenReturn(categoryDto);

        CategoryDto createdCategory = categoryService.createCategory(categoryDto);

        assertNotNull(createdCategory);
        assertEquals(categoryDto.getCategoryTitle(), createdCategory.getCategoryTitle());
        verify(categoryRepo, times(1)).save(any(Category.class));
    }

    @Test
    public void testUpdateCategory() {
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(category));
        when(categoryRepo.save(any(Category.class))).thenReturn(category);
        when(modelMapper.map(any(Category.class), eq(CategoryDto.class))).thenReturn(categoryDto);

        CategoryDto updatedCategory = categoryService.updateCategory(categoryDto, 1);

        assertNotNull(updatedCategory);
        assertEquals(categoryDto.getCategoryTitle(), updatedCategory.getCategoryTitle());
        verify(categoryRepo, times(1)).findById(anyInt());
        verify(categoryRepo, times(1)).save(any(Category.class));
    }

    @Test
    public void testDeleteCategory() {
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(category));
        doNothing().when(categoryRepo).delete(any(Category.class));

        categoryService.deleteCategory(1);

        verify(categoryRepo, times(1)).findById(anyInt());
        verify(categoryRepo, times(1)).delete(any(Category.class));
    }

    @Test
    public void testGetCategory() {
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(category));
        when(modelMapper.map(any(Category.class), eq(CategoryDto.class))).thenReturn(categoryDto);

        CategoryDto foundCategory = categoryService.getCategory(1);

        assertNotNull(foundCategory);
        assertEquals(categoryDto.getCategoryTitle(), foundCategory.getCategoryTitle());
        verify(categoryRepo, times(1)).findById(anyInt());
    }

    @Test
    public void testGetCategories() {
        List<Category> categories = Arrays.asList(category);
        List<CategoryDto> categoryDtos = categories.stream()
            .map(cat -> modelMapper.map(cat, CategoryDto.class))
            .collect(Collectors.toList());

        when(categoryRepo.findAll()).thenReturn(categories);
        when(modelMapper.map(any(Category.class), eq(CategoryDto.class))).thenReturn(categoryDto);

        List<CategoryDto> allCategories = categoryService.getCategories();

        assertNotNull(allCategories);
        assertEquals(1, allCategories.size());
        assertEquals(categoryDto.getCategoryTitle(), allCategories.get(0).getCategoryTitle());
        verify(categoryRepo, times(1)).findAll();
    }

    @Test
    public void testGetCategory_CategoryNotFound() {
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> categoryService.getCategory(1));
        verify(categoryRepo, times(1)).findById(anyInt());
    }
}
