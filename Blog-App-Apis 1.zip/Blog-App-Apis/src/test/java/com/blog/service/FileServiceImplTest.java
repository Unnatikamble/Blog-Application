package com.blog.service;


import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.blog.serviceimpl.FileServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

public class FileServiceImplTest {

    @InjectMocks
    private FileServiceImpl fileService;

    @Mock
    private MultipartFile multipartFile;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testUploadImage() throws IOException {
        String path = "uploads";
        String originalFileName = "test.png";
        String contentType = "image/png";
        byte[] content = "some content".getBytes();

        // Mocking MultipartFile methods
        when(multipartFile.getOriginalFilename()).thenReturn(originalFileName);
        when(multipartFile.getInputStream()).thenReturn(new ByteArrayInputStream(content));
        when(multipartFile.getContentType()).thenReturn(contentType);

        // Prepare the uploads directory
        File uploadDir = new File(path);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        String uploadedFileName = fileService.uploadImage(path, multipartFile);

        // Verify that the file is uploaded correctly
        assertTrue(Files.exists(Paths.get(path, uploadedFileName)));
        assertEquals(originalFileName, uploadedFileName);

        // Cleanup the uploaded file
        Files.delete(Paths.get(path, uploadedFileName));
    }

    @Test
    public void testGetResource() throws FileNotFoundException {
        String path = "uploads";
        String fileName = "test.png";
        String fullPath = path + File.separator + fileName;

        // Create a dummy file to read from
        try (FileOutputStream fos = new FileOutputStream(fullPath)) {
            fos.write("some content".getBytes());
        } catch (IOException e) {
            fail("Failed to create test file");
        }

        InputStream inputStream = fileService.getResource(path, fileName);

        // Verify that the InputStream is not null and can read content
        assertNotNull(inputStream);
        try {
            assertEquals("some content", new String(inputStream.readAllBytes()));
        } catch (IOException e) {
            fail("Failed to read content from InputStream");
        }

        // Cleanup the dummy file
        new File(fullPath).delete();
    }
}
