package com.blog.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.blog.entity.Category;
import com.blog.entity.Post;
import com.blog.entity.User;
import com.blog.exception.ResourceNotFoundException;
import com.blog.payloads.PostDto;
import com.blog.payloads.PostResponse;
import com.blog.repository.CategoryRepo;
import com.blog.repository.PostRepo;
import com.blog.repository.UserRepo;
import com.blog.serviceimpl.PostServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.*;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class PostServiceImplTest {
//
//    @InjectMocks
//    private PostServiceImpl postService;
//
//    @Mock
//    private PostRepo postRepo;
//
//    @Mock
//    private ModelMapper modelMapper;
//
//    @Mock
//    private UserRepo userRepo;
//
//    @Mock
//    private CategoryRepo categoryRepo;
//
//    private Post post;
//    private PostDto postDto;
//    private User user;
//    private Category category;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//
//        user = new User();
//        user.setId(1);
//        user.setName("Test User");
//
//        category = new Category();
//        category.setCategoryTitle("Test Category");
//
//        post = new Post();
//        post.setPostId(1);
//        post.setTitle("Test Post");
//        post.setContent("Test Content");
//        post.setImageName("default.png");
//        post.setAddedDate(new Date());
//        post.setUser(user);
//        post.setCategory(category);
//
//        postDto = new PostDto();
//        postDto.setPostId(1);
//        postDto.setTitle("Test Post");
//        postDto.setContent("Test Content");
//        postDto.setImageName("default.png");
//    
//    }
//
//    @Test
//    public void testCreatePost() {
//        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
//        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(category));
//        when(modelMapper.map(any(PostDto.class), eq(Post.class))).thenReturn(post);
//        when(postRepo.save(any(Post.class))).thenReturn(post);
//        when(modelMapper.map(any(Post.class), eq(PostDto.class))).thenReturn(postDto);
//
//        PostDto createdPost = postService.createPost(postDto, 1, 1);
//
//        assertNotNull(createdPost);
//        assertEquals(postDto.getTitle(), createdPost.getTitle());
//        verify(userRepo, times(1)).findById(anyInt());
//        verify(categoryRepo, times(1)).findById(anyInt());
//        verify(postRepo, times(1)).save(any(Post.class));
//    }
//
//    @Test
//    @Order(value = 1)
//    public void testCreatePost_UserNotFound() {
//        when(userRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.createPost(postDto, 1, 1));
//        verify(userRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testCreatePost_CategoryNotFound() {
//        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
//        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.createPost(postDto, 1, 1));
//        verify(categoryRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testUpdatePost() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.of(post));
//        when(postRepo.save(any(Post.class))).thenReturn(post);
//        when(modelMapper.map(any(Post.class), eq(PostDto.class))).thenReturn(postDto);
//
//        PostDto updatedPost = postService.updatePost(postDto, 1);
//
//        assertNotNull(updatedPost);
//        assertEquals(postDto.getTitle(), updatedPost.getTitle());
//        verify(postRepo, times(1)).findById(anyInt());
//        verify(postRepo, times(1)).save(any(Post.class));
//    }
//
//    @Test
//    public void testUpdatePost_PostNotFound() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.updatePost(postDto, 1));
//        verify(postRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testDeletePost() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.of(post));
//        doNothing().when(postRepo).delete(any(Post.class));
//
//        postService.deletePost(1);
//
//        verify(postRepo, times(1)).findById(anyInt());
//        verify(postRepo, times(1)).delete(any(Post.class));
//    }
//
//    @Test
//    public void testDeletePost_PostNotFound() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.deletePost(1));
//        verify(postRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testGetAllPost() {
//        Page<Post> pagePosts = new PageImpl<>(Arrays.asList(post));
//        when(postRepo.findAll(any(Pageable.class))).thenReturn(pagePosts);
//
//        PostResponse postResponse = postService.getAllPost(0, 5, "id", "asc");
//
//        assertNotNull(postResponse);
//        assertEquals(1, postResponse.getContent().size());
//        verify(postRepo, times(1)).findAll(any(Pageable.class));
//    }
//
//    @Test
//    public void testGetPostById() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.of(post));
//        when(modelMapper.map(any(Post.class), eq(PostDto.class))).thenReturn(postDto);
//
//        PostDto foundPost = postService.getPostById(1);
//
//        assertNotNull(foundPost);
//        assertEquals(postDto.getTitle(), foundPost.getTitle());
//        verify(postRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testGetPostById_PostNotFound() {
//        when(postRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.getPostById(1));
//        verify(postRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testGetPostsByCategory() {
//        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(category));
//        when(postRepo.findByCategory(any(Category.class))).thenReturn(Arrays.asList(post));
//
//        List<PostDto> posts = postService.getPostsByCategory(1);
//
//        assertNotNull(posts);
//        assertEquals(1, posts.size());
//        verify(categoryRepo, times(1)).findById(anyInt());
//        verify(postRepo, times(1)).findByCategory(any(Category.class));
//    }
//
//    @Test
//    public void testGetPostsByCategory_CategoryNotFound() {
//        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.getPostsByCategory(1));
//        verify(categoryRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testGetPostsByUser() {
//        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
//        when(postRepo.findByUser(any(User.class))).thenReturn(Arrays.asList(post));
//
//        List<PostDto> posts = postService.getPostsByUser(1);
//
//        assertNotNull(posts);
//        assertEquals(1, posts.size());
//        verify(userRepo, times(1)).findById(anyInt());
//        verify(postRepo, times(1)).findByUser(any(User.class));
//    }
//
//    @Test
//    public void testGetPostsByUser_UserNotFound() {
//        when(userRepo.findById(anyInt())).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> postService.getPostsByUser(1));
//        verify(userRepo, times(1)).findById(anyInt());
//    }
//
//    @Test
//    public void testSearchPosts() {
//        when(postRepo.findByTitleContaining(anyString())).thenReturn(Arrays.asList(post));
//
//        List<PostDto> posts = postService.searchPosts("Test");
//
//        assertNotNull(posts);
//        assertEquals(1, posts.size());
//        verify(postRepo, times(1)).findByTitleContaining(anyString());
//    }
}

