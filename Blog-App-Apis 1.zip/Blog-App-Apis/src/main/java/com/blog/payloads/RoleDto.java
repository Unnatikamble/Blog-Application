package com.blog.payloads;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class RoleDto {
	
	@NotNull
	private int id;
	
	@NotNull
	private String Name;

}
