package com.blog.payloads;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PostDto1 {

    private Integer postId;
    
    @NotEmpty
    private String title;
    
    private String content;
    
    private byte[] imageName;
   
    
    private Date addedDate;
}
