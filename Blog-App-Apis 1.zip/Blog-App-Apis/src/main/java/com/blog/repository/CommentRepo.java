package com.blog.repository;

import com.blog.entity.Comment;
import com.blog.entity.Post;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CommentRepo extends JpaRepository<Comment, Integer> {

//	 List<Comment> findByPostId(Integer postId);
	@Query("SELECT c FROM Comment c WHERE c.post.id = :postId")
    List<Comment> findByPostId(@Param("postId") Integer postId);
	
}
