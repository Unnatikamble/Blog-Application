package com.blog.service;

import com.blog.entity.Post;
import com.blog.payloads.PostDto;
import com.blog.payloads.PostDto1;
import com.blog.payloads.PostResponse;

import java.util.List;

public interface PostService {
   //create
    PostDto createPost(PostDto postDto,Integer userId,Integer categoryId);

    //update
    PostDto updatePost(PostDto postDto, Integer postId);

    //delete
    void deletePost(Integer postId);

    //get all posts
    PostResponse getAllPost(Integer pageNumber, Integer pageSize,String sortBy, String sortDir);
    
    List<PostDto1>getAllPost1();

    //get single post
//    PostDto getPostById(Integer postId);
    PostDto1 getPostById(Integer postId);

    //get all post by category

    List<PostDto1> getPostsByCategory(Integer categoryId);

    //get all posts by user
    List<PostDto1> getPostsByUser(Integer userId);

    //searching
    List<PostDto> searchPosts(String keyword);

}
