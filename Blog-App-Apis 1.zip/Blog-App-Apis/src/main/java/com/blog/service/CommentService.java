package com.blog.service;

import java.util.List;

import com.blog.entity.Comment;
import com.blog.payloads.CommentDto;

public interface CommentService {

    CommentDto createComment(CommentDto commentDto, Integer postId);

    void deleteComment(Integer commentId);
    
    List<CommentDto> getCommentsByPostId(Integer postId);
    
    //List<Comment> findByPostId(Integer postId);
}
