package com.blog.serviceimpl;

import com.blog.entity.Comment;
import com.blog.entity.Post;
import com.blog.exception.ResourceNotFoundException;
import com.blog.payloads.CommentDto;
import com.blog.repository.CommentRepo;
import com.blog.repository.PostRepo;
import com.blog.service.CommentService;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private PostRepo postRepo;

    @Autowired
    private CommentRepo commentRepo;

    private ModelMapper modelMapper;

    @Override
    public CommentDto createComment(CommentDto commentDto, Integer postId) {
    	System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii1");
        Post post = this.postRepo.findById(postId).orElseThrow(()-> new ResourceNotFoundException("post", "post id", postId));
       // Comment comment=this.modelMapper.map(commentDto, Comment.class);
        Comment comment=new Comment();
             comment.setContent(commentDto.getContent());
        comment.setPost(post);
        System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii3");
        Comment savedComment = this.commentRepo.save(comment);
        System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii5");
        // this.modelMapper.map(savedComment, CommentDto.class) ;
        CommentDto cdt1=new CommentDto();
        cdt1.setId(savedComment.getId());
        cdt1.setContent(savedComment.getContent());
         return cdt1;
    }
    @Override
    public void deleteComment(Integer commentId) {
     Comment com = this.commentRepo.findById(commentId).orElseThrow(()->new ResourceNotFoundException("Comment", "CommentId", commentId));
     this.commentRepo.delete(com);
    }
    @Transactional
    public List<CommentDto> getCommentsByPostId(Integer postId) {
        List<Comment> comments = commentRepo.findByPostId(postId);
        return comments.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private CommentDto mapToDto(Comment comment) {
        CommentDto commentDto = new CommentDto();
        commentDto.setId(comment.getId());
        commentDto.setContent(comment.getContent());
        return commentDto;
    }
	
}
