
package com.blog.controller;

import com.blog.entity.User;
import com.blog.exception.ApiException;
import com.blog.payloads.JwtAuthRequest;
import com.blog.payloads.JwtAuthResponse;
import com.blog.payloads.UserDto;
import com.blog.payloads.UserDto1;
import com.blog.repository.UserRepo;
import com.blog.security.JwtTokenHelper;
import com.blog.service.UserService;
import com.blog.serviceimpl.UserServiceImpl;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@Slf4j
@RestController
//@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private JwtTokenHelper jwtTokenHelper;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepo userRepo;


    @PostMapping("/login")
    public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
        this.authenticate(request.getUsername(),request.getPassword());
       UserDetails userDetails = this.userDetailsService.loadUserByUsername(request.getUsername());
        String token =this.jwtTokenHelper.generateToken(userDetails);
         
        User userDto=this.userRepo.findByEmail(request.getUsername()).get();
        

        JwtAuthResponse response = new JwtAuthResponse();
        response.setToken(token);
        response.setId(userDto.getId());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
        private void authenticate(String username, String password) throws Exception {
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password);
        try {
            this.authenticationManager.authenticate(authenticationToken);
        
        }catch(BadCredentialsException e){
            System.out.println("Invalid details !!");
            throw new ApiException("Invalid username or password");
        }
        }
        
        //register new user api
        
        @PostMapping("/register")
        public ResponseEntity<UserDto> registerUser(@RequestBody UserDto userDto){
        	
        	UserDto registeredUser =this.userService.registerNewUser(userDto);
        	
        	log.info("user register Successfully: {}", registeredUser);
        	return new ResponseEntity<UserDto>(registeredUser,HttpStatus.CREATED);
        }
        
        @GetMapping("/users/{userId}")
    	public ResponseEntity<UserDto1> getSingleUsers(@PathVariable Integer userId) {
    		return ResponseEntity.ok(this.userService.getUserById1(userId));
    	}
}



